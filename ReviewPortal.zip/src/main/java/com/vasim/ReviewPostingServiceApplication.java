package com.vasim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewPostingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewPostingServiceApplication.class, args);
	}

}
