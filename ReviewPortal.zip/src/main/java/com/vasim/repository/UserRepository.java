package com.vasim.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.vasim.entity.ItemEntity;
import com.vasim.entity.UserEntity;
import java.util.*;

import jakarta.transaction.Transactional;

public interface UserRepository extends JpaRepository<UserEntity, Integer> {
	
	
	@Transactional
	@Query("from UserEntity e where e.email=:email")
	public Optional<UserEntity> canUserLogin(@Param("email") String email);
	
	
	@Transactional
	@Query("from UserEntity e where e.email=:email")
	public UserEntity getUserIdByMail(@Param("email") String email);
}
