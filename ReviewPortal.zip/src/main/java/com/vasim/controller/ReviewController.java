package com.vasim.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vasim.dto.ItemDTO;
import com.vasim.dto.LoginDTO;
import com.vasim.dto.ReplyDTO;
import com.vasim.dto.ReviewDTO;
import com.vasim.dto.SearchReplyDTO;
import com.vasim.dto.UserDTO;
import com.vasim.entity.ItemEntity;
import com.vasim.entity.ReviewEntity;
import com.vasim.service.ReviewService;
import com.vasim.vo.ItemVO;
import com.vasim.vo.RepliesVO;
import com.vasim.vo.UseridVO;

@RestController
@CrossOrigin
@RequestMapping("portal")
public class ReviewController {
	
	@Autowired
	private ReviewService reviewService;
	
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "getrepliesbyitemidandreviewid")
	public List<RepliesVO> getRepliesByItemIdAndReviewId(@RequestBody SearchReplyDTO dto) {
		return reviewService.getRepliesByItemIdAndReviewId(dto);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "addreply")
	public boolean addReply(@RequestBody ReplyDTO dto) {
		return reviewService.addReply(dto);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "searchbyitemcategory/{itemcategory}")
	public List<ItemEntity> searchByItemCategory(@PathVariable String itemcategory) {
		return reviewService.searchByItemCategory(itemcategory);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "searchbyitemname/{itemname}")
	public List<ItemEntity> searchByItemName(@PathVariable String itemname) {
		return reviewService.searchByItemName(itemname);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "getloggedinuserid/{email}")
	public UseridVO getUserIdByMail(@PathVariable String email) {
		return reviewService.getUserIdByMail(email);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "login")
	public Integer canUserLogin(@RequestBody LoginDTO dto) {
		return reviewService.canUserLogin(dto);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "adduser")
	public boolean addUser(@RequestBody UserDTO dto) {
		return reviewService.addUser(dto);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "getallitems")
	public List<ItemVO> getAllItems() {
		return reviewService.getAllItems();
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "additem")
	public ItemEntity addItem(@RequestBody ItemDTO dto) {
		return reviewService.addItem(dto);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "addreview")
	public Integer addReview(@RequestBody ReviewDTO review) {
		return reviewService.addReview(review);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "getreview/{itemid}")
	public List<ReviewEntity> getAllReviewsByItemId(@PathVariable Integer itemid) {
		return reviewService.getReviewsByItemId(itemid);
	}
	
	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST},value = "getusersreview/{userid}")
	public List<ReviewEntity> getAllReviewsByUserId(@PathVariable Integer userid) {
		return reviewService.getReviewsByUserId(userid);
	}
}
