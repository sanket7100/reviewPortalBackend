package com.vasim.dao;

import java.util.List;
import java.util.Optional;

import com.vasim.entity.ItemEntity;
import com.vasim.entity.ReplyEntity;
import com.vasim.entity.ReviewEntity;
import com.vasim.entity.UserEntity;

public interface ReviewDAO {

	List<ReviewEntity> getReviewsByItemId(Integer itemid);

	ReviewEntity addReview(ReviewEntity entity);

	Optional<ReviewEntity> isReviewExistForUser(Integer userid, Integer itemid);

	ItemEntity addItem(ItemEntity item);

	List<ItemEntity> getAllItems();

	UserEntity addUser(UserEntity user);

	Optional<UserEntity> canUserLogin(String email);

	List<ReviewEntity> getReviewsByUserId(Integer userid);

	UserEntity getUserIdByMail(String email);

	List<ItemEntity> searchByItemName(String itemname);

	List<ItemEntity> searchByItemCategory(String itemcategory);

	ReplyEntity addReply(ReplyEntity reply);

	List<ReplyEntity> getRepliesByItemIdAndReviewId(Integer itemid, Integer reviewid);

	Double getAverageRatingByItemId(Integer itemid);

}