package com.vasim.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vasim.dao.ReviewDAO;
import com.vasim.dto.ItemDTO;
import com.vasim.dto.LoginDTO;
import com.vasim.dto.ReplyDTO;
import com.vasim.dto.ReviewDTO;
import com.vasim.dto.SearchReplyDTO;
import com.vasim.dto.UserDTO;
import com.vasim.entity.ItemEntity;
import com.vasim.entity.ReplyEntity;
import com.vasim.entity.ReviewEntity;
import com.vasim.entity.UserEntity;
import com.vasim.vo.ItemVO;
import com.vasim.vo.RepliesVO;
import com.vasim.vo.UseridVO;

@Service
public class ReviewServiceImpl implements ReviewService {
	
	@Autowired
	private ReviewDAO reviewDAO;
	
	
	
	
	
	@Override
	public Double getAverageRatingByItemId(Integer itemid) {
		return reviewDAO.getAverageRatingByItemId(itemid);
	}
	
	
	@Override
	public List<RepliesVO> getRepliesByItemIdAndReviewId(SearchReplyDTO dto) {
		var list=reviewDAO.getRepliesByItemIdAndReviewId(dto.getItemid(), dto.getReviewid());
		List<RepliesVO> replies=new ArrayList<>();
		
		for(var x:list) {
			RepliesVO reply=new RepliesVO(x.getFk_username(),x.getReply());
			replies.add(reply);
		}
		return replies;
	}
	
	@Override
	public boolean addReply(ReplyDTO dto) {
		ReplyEntity reply=new ReplyEntity();
		reply.setFk_username(dto.getFk_username());
		reply.setReply(dto.getReply());
		reply.setFk_itemid(dto.getFk_itemid());
		reply.setFk_reviewid(dto.getFk_reviewid());
		var response=reviewDAO.addReply(reply);
		return response!=null?true:false;
	}
	
	@Override
	public List<ItemEntity> searchByItemCategory(String itemcategory) {
		return reviewDAO.searchByItemCategory(itemcategory);
	}
	
	@Override
	public List<ItemEntity> searchByItemName(String itemname) {
		return reviewDAO.searchByItemName(itemname);
	}
	
	@Override
	public UseridVO getUserIdByMail(String email) {
		var userEntity=reviewDAO.getUserIdByMail(email);
		UseridVO useridVO=new UseridVO(userEntity.getUserid());
		return useridVO;
	}
	
	@Override
	public Integer canUserLogin(LoginDTO dto) {
		
		String email=dto.getEmail();
		String password=dto.getPassword();
		var optional=reviewDAO.canUserLogin(dto.getEmail());
		
		if(optional.isPresent()) {
			if(email.equals(optional.get().getEmail() ) && password.equals(optional.get().getPassword())) return 1;
			else return 2;
		}
		return 3;

	}
	
	@Override
	public boolean addUser(UserDTO dto) {
		UserEntity entity=new UserEntity();
		entity.setEmail(dto.getEmail());
		entity.setPassword(dto.getPassword());
		entity.setUsername(dto.getUsername());
		var DBentity=reviewDAO.addUser(entity);
		return DBentity!=null?true:false;
	}
	
	@Override
	public List<ItemVO> getAllItems() {
		var list=reviewDAO.getAllItems();
		List<ItemVO> items=new ArrayList<>();
		
		for(var x:list) {
			Double avgRating=reviewDAO.getAverageRatingByItemId(x.getItemid());
			ItemVO item=new ItemVO(x.getItemid(),x.getFk_userid(),x.getItemname(),x.getItemcategory(),x.getItemdescription(),x.getCreationtime(),avgRating);
			items.add(item);
		}
		
		return items;
	}
	
	@Override
	public ItemEntity addItem(ItemDTO dto) {
		
		ItemEntity item=new ItemEntity();
		item.setFk_userid(dto.getFk_userid());
		item.setItemname(dto.getItemname());
		item.setItemcategory(dto.getItemcategory());
		item.setItemdescription(dto.getItemdescription());
		
		return reviewDAO.addItem(item);
	}
	
	@Override
	public boolean isReviewExistForUser(Integer userid,Integer itemid) {
		var res=reviewDAO.isReviewExistForUser(userid, itemid);
		if(res.isPresent()) return true;//review exist for user
		return false;//review not exist
	}
	
	@Override
	public Integer addReview(ReviewDTO dto) {
		
		boolean isReviewExistForUser=isReviewExistForUser(dto.getFk_userid(), dto.getFk_itemid());
		if(isReviewExistForUser) return 2;//exist
		
		ReviewEntity entity=new ReviewEntity();
		entity.setFk_userid(dto.getFk_userid());
		entity.setFk_itemid(dto.getFk_itemid());
		entity.setFk_username(dto.getFk_username());
		entity.setRating(dto.getRating());
		entity.setReview(dto.getReview());
		var res=reviewDAO.addReview(entity);
		return res!=null?1:3;//1->added//3-NotAdded
	}
	
	@Override
	public List<ReviewEntity> getReviewsByItemId(Integer itemid) {
		return reviewDAO.getReviewsByItemId(itemid);
	}
	
	@Override
	public List<ReviewEntity> getReviewsByUserId(Integer userid) {
		return reviewDAO.getReviewsByUserId(userid);
	}
}
