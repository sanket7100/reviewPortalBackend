package com.vasim.service;

import java.util.List;

import com.vasim.dto.ItemDTO;
import com.vasim.dto.LoginDTO;
import com.vasim.dto.ReplyDTO;
import com.vasim.dto.ReviewDTO;
import com.vasim.dto.SearchReplyDTO;
import com.vasim.dto.UserDTO;
import com.vasim.entity.ItemEntity;
import com.vasim.entity.ReviewEntity;
import com.vasim.entity.UserEntity;
import com.vasim.vo.ItemVO;
import com.vasim.vo.RepliesVO;
import com.vasim.vo.UseridVO;

public interface ReviewService {

	List<ReviewEntity> getReviewsByItemId(Integer itemid);

	Integer addReview(ReviewDTO dto);

	boolean isReviewExistForUser(Integer userid, Integer itemid);

	ItemEntity addItem(ItemDTO dto);

	List<ItemVO> getAllItems();

	boolean addUser(UserDTO dto);

	Integer canUserLogin(LoginDTO dto);

	List<ReviewEntity> getReviewsByUserId(Integer userid);

	UseridVO getUserIdByMail(String email);

	List<ItemEntity> searchByItemName(String itemname);

	List<ItemEntity> searchByItemCategory(String itemcategory);

	boolean addReply(ReplyDTO dto);

	List<RepliesVO> getRepliesByItemIdAndReviewId(SearchReplyDTO dto);

	Double getAverageRatingByItemId(Integer itemid);

}